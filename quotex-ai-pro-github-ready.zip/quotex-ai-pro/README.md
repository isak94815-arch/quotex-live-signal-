# QUOTEX AI PRO — GitHub-ready starter

A mobile-friendly technical-analysis dashboard for the 17 Quotex currency pairs supplied by the user.

## Run locally
Open `index.html` in a modern browser. No build step or paid service is required.

## Publish with GitHub Pages
1. Upload `index.html` and this README to the repository.
2. In GitHub, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main`, folder `/ (root)`, then Save.
5. Wait for the Pages URL to appear in Settings → Pages.

## Important limitations
- This is a technical-analysis starter, not an automatic Quotex connection.
- It does not fetch Quotex candles or OTC prices. The user must enter recent candle close prices and the latest OHLC values.
- OTC prices may be platform-specific and are not necessarily available from public market-data feeds.
- RSI/EMA/MACD rules produce an educational UP/DOWN/WAIT bias, not guaranteed predictions, verified win rates, or financial advice.
- Test on a demo account first. Never risk money you cannot afford to lose.

## Supported pairs
USD/EGP (OTC), AUD/NZD (OTC), USD/NGN (OTC), USD/INR (OTC), USD/ZAR (OTC), AUD/JPY, USD/MXN (OTC), CAD/CHF (OTC), EUR/JPY, GBP/NZD (OTC), USD/DZD (OTC), GBP/USD, USD/BDT (OTC), AUD/USD, EUR/AUD, USD/CAD, USD/JPY.
